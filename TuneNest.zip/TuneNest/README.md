# TuneNest

Personal Android music app: your own categories and playlists, Apple Music-style Now Playing,
one queue across YouTube, your phone's music files, and live radio.

## Build the APK (GitHub)
1. Create a new GitHub repo (private is fine) and upload everything in this folder,
   including the hidden `.github` folder and `gradle/wrapper/gradle-wrapper.jar`.
2. Open the repo's **Actions** tab. "Build APK" runs automatically on every push
   (or press **Run workflow**).
3. When it turns green, open the run and download **TuneNest-apk** at the bottom. Unzip and install.

Every build is signed with the same key (`app/tunenest-debug.jks`), so new builds install as
updates and your library is kept.

## First-time setup in the app
**YouTube search (free):** Settings → YouTube search shows the steps. In short:
console.cloud.google.com → new project → enable *YouTube Data API v3* → Credentials →
API key → restrict it to YouTube Data API v3 → paste into the app. Free quota is about
100 searches a day; playing songs and browsing playlists don't use it.

**My files:** Search → My files → Allow access.

**Poster mode (YouTube songs without video):**
1. Install YouTube Music and sign in with your Premium account.
2. Settings → Allow access → turn on TuneNest under Notification access.
   If Android says it's a *restricted setting*: App info → ⋮ → Allow restricted settings → try again.

## How playback works
| Source | Plays through | Background / screen off |
|---|---|---|
| My files, Radio | Built-in player | Yes, with lock-screen controls |
| YouTube — Video | Official YouTube player inside the app | No (YouTube's rules) |
| YouTube — Poster | YouTube Music app (your Premium) | Yes |

In Poster mode, when the queue moves to the next YouTube song, YouTube Music may briefly open.
Some videos block playback inside other apps; those switch to YouTube Music automatically.

## Where things are
- `data/` — library storage (`library.json` on the phone), models, settings
- `net/` — YouTube Data API, radio directory, local files
- `playback/` — queue controller, background service, YouTube player host, YouTube Music bridge
- `ui/` — screens (Library, Playlist, Search, Settings, Now Playing)

To rename the app, change `app_name` in `app/src/main/res/values/strings.xml`.
