package com.sathish.tunenest.ui

import android.view.ViewGroup
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView
import com.sathish.tunenest.TuneApp
import com.sathish.tunenest.data.Song
import com.sathish.tunenest.playback.Engine
import kotlin.math.roundToInt

sealed class Screen {
    data object Library : Screen()
    data object Search : Screen()
    data object Settings : Screen()
    data class PlaylistDetail(val id: String) : Screen()
    data class Smart(val kind: SmartKind) : Screen()
}

@Composable
fun AppRoot(app: TuneApp, ytView: YouTubePlayerView, resumeTick: Int) {
    val controller = app.player
    val store = app.library
    val library by store.state.collectAsState()
    val ui by controller.ui.collectAsState()

    val stack = remember { mutableStateListOf<Screen>(Screen.Library) }
    var nowPlayingOpen by remember { mutableStateOf(false) }
    var libraryFilter by remember { mutableStateOf<String?>(null) }
    val searchState = remember { SearchState() }
    var sheetSong by remember { mutableStateOf<Song?>(null) }
    var showQueue by remember { mutableStateOf(false) }
    var miniSlot by remember { mutableStateOf<Rect?>(null) }
    var fullSlot by remember { mutableStateOf<Rect?>(null) }
    var apiKey by remember { mutableStateOf(app.prefs.youtubeApiKey) }

    fun push(s: Screen) {
        stack.add(s)
    }

    fun pop() {
        if (stack.size > 1) stack.removeAt(stack.lastIndex)
    }

    fun selectTab(tab: Screen) {
        nowPlayingOpen = false
        stack.clear()
        stack.add(tab)
    }

    LaunchedEffect(ui.current) {
        if (ui.current == null) nowPlayingOpen = false
    }

    BackHandler(enabled = nowPlayingOpen || stack.size > 1) {
        if (nowPlayingOpen) nowPlayingOpen = false else pop()
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Palette.Bg)
    ) {
        Column(Modifier.fillMaxSize()) {
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                when (val s = stack.last()) {
                    Screen.Library -> LibraryScreen(
                        library = library,
                        store = store,
                        filter = libraryFilter,
                        onFilter = { libraryFilter = it },
                        onOpenPlaylist = { push(Screen.PlaylistDetail(it)) },
                        onOpenSmart = { push(Screen.Smart(it)) },
                    )
                    Screen.Search -> SearchScreen(
                        state = searchState,
                        library = library,
                        store = store,
                        controller = controller,
                        apiKey = apiKey,
                        currentSongId = ui.current?.id,
                        onAddToPlaylist = { sheetSong = it },
                    )
                    Screen.Settings -> SettingsScreen(
                        app = app,
                        library = library,
                        apiKey = apiKey,
                        onApiKeyChange = {
                            app.prefs.youtubeApiKey = it
                            apiKey = it
                        },
                        resumeTick = resumeTick,
                        onOpenPlaylist = { push(Screen.PlaylistDetail(it)) },
                    )
                    is Screen.PlaylistDetail -> PlaylistScreen(
                        playlistId = s.id,
                        smart = null,
                        library = library,
                        store = store,
                        controller = controller,
                        currentSongId = ui.current?.id,
                        onBack = { pop() },
                        onAddToPlaylist = { sheetSong = it },
                    )
                    is Screen.Smart -> PlaylistScreen(
                        playlistId = null,
                        smart = s.kind,
                        library = library,
                        store = store,
                        controller = controller,
                        currentSongId = ui.current?.id,
                        onBack = { pop() },
                        onAddToPlaylist = { sheetSong = it },
                    )
                }
            }
            if (ui.current != null) {
                MiniPlayer(
                    ui = ui,
                    controller = controller,
                    onOpen = { nowPlayingOpen = true },
                    onVideoSlot = { miniSlot = it },
                )
            }
            NavBar(
                selected = stack.first(),
                onSelect = { selectTab(it) },
            )
        }

        if (nowPlayingOpen && ui.current != null) {
            NowPlayingScreen(
                ui = ui,
                library = library,
                controller = controller,
                onToggleLike = { store.toggleLike(it) },
                onAddToPlaylist = { sheetSong = it },
                onShowQueue = { showQueue = true },
                onClose = { nowPlayingOpen = false },
                onVideoSlot = { fullSlot = it },
            )
        }

        // The single YouTube player, moved over whichever video box is on screen.
        val slot = if (ui.engine == Engine.YT_EMBED) (if (nowPlayingOpen) fullSlot else miniSlot) else null
        val density = LocalDensity.current
        val playerModifier = if (slot != null) {
            Modifier
                .offset { IntOffset(slot.left.roundToInt(), slot.top.roundToInt()) }
                .size(
                    width = with(density) { slot.width.toDp() },
                    height = with(density) { slot.height.toDp() },
                )
        } else {
            Modifier.size(1.dp)
        }
        AndroidView(
            factory = {
                (ytView.parent as? ViewGroup)?.removeView(ytView)
                ytView
            },
            modifier = playerModifier,
        )
    }

    sheetSong?.let { song ->
        AddToPlaylistSheet(song = song, store = store, onDismiss = { sheetSong = null })
    }
    if (showQueue) {
        QueueSheet(ui = ui, controller = controller, onDismiss = { showQueue = false })
    }
}

@Composable
private fun NavBar(selected: Screen, onSelect: (Screen) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .height(64.dp)
            .background(Palette.Bg),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        NavItem(Icons.Filled.LibraryMusic, "Library", selected == Screen.Library, Modifier.weight(1f)) { onSelect(Screen.Library) }
        NavItem(Icons.Filled.Search, "Search", selected == Screen.Search, Modifier.weight(1f)) { onSelect(Screen.Search) }
        NavItem(Icons.Filled.Settings, "Settings", selected == Screen.Settings, Modifier.weight(1f)) { onSelect(Screen.Settings) }
    }
}

@Composable
private fun NavItem(icon: ImageVector, label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val color = if (selected) Palette.Accent else Palette.TextDim
    Column(
        modifier
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, contentDescription = null, tint = color)
        Text(label, color = color, fontSize = 12.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
    }
}
