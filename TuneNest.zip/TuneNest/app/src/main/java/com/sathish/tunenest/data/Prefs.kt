package com.sathish.tunenest.data

import android.content.Context

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("tunenest_prefs", Context.MODE_PRIVATE)

    var youtubeApiKey: String
        get() = sp.getString("yt_api_key", "") ?: ""
        set(value) = sp.edit().putString("yt_api_key", value.trim()).apply()

    /** true = show the YouTube video, false = poster only (audio via YouTube Music). */
    var videoMode: Boolean
        get() = sp.getBoolean("video_mode", true)
        set(value) = sp.edit().putBoolean("video_mode", value).apply()
}
