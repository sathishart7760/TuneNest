@file:OptIn(ExperimentalMaterial3Api::class)

package com.sathish.tunenest.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sathish.tunenest.data.LibraryStore
import com.sathish.tunenest.data.Playlist
import com.sathish.tunenest.data.Song
import com.sathish.tunenest.playback.PlayerController
import com.sathish.tunenest.playback.PlayerUi

@Composable
fun AddToPlaylistSheet(song: Song, store: LibraryStore, onDismiss: () -> Unit) {
    val library by store.state.collectAsState()
    var newPlaylist by remember { mutableStateOf(false) }
    var newCategory by remember { mutableStateOf(false) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = Palette.Surface,
    ) {
        Column(
            Modifier
                .padding(horizontal = 20.dp)
                .padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Artwork(song, Modifier.size(44.dp))
                Column(Modifier.padding(start = 12.dp)) {
                    Text("Add to playlist", color = Palette.TextDim, fontSize = 12.sp)
                    Text(
                        song.title,
                        color = Palette.Text,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }

            LazyColumn(Modifier.heightIn(max = 380.dp)) {
                if (library.playlists.isEmpty()) {
                    item { HintText("No playlists yet. Create one below.", Modifier.padding(vertical = 8.dp)) }
                }
                library.categories.forEachIndexed { idx, cat ->
                    val inCat = library.playlistsIn(cat.id)
                    if (inCat.isNotEmpty()) {
                        item {
                            val color = Palette.categoryColors[idx % Palette.categoryColors.size].second
                            Text(
                                cat.name,
                                color = color,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                modifier = Modifier.padding(top = 10.dp, bottom = 2.dp),
                            )
                        }
                        items(inCat) { p -> PlaylistCheckRow(p, song, store) }
                    }
                }
                val loose = library.playlistsIn(null)
                if (loose.isNotEmpty()) {
                    item {
                        Text(
                            "Other playlists",
                            color = Palette.TextDim,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(top = 10.dp, bottom = 2.dp),
                        )
                    }
                    items(loose) { p -> PlaylistCheckRow(p, song, store) }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = { newPlaylist = true }, modifier = Modifier.weight(1f)) {
                    Text("New playlist", color = Palette.Text)
                }
                OutlinedButton(onClick = { newCategory = true }, modifier = Modifier.weight(1f)) {
                    Text("New category", color = Palette.Text)
                }
            }
            Button(
                onClick = onDismiss,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                shape = RoundedCornerShape(24.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Palette.Accent, contentColor = Palette.Bg),
            ) { Text("Done", fontWeight = FontWeight.Bold) }
        }
    }

    if (newPlaylist) {
        NewPlaylistDialog(
            categories = library.categories,
            initialCategoryId = null,
            onDismiss = { newPlaylist = false },
            onCreate = { name, catId ->
                store.createPlaylist(name, catId, listOf(song))
                newPlaylist = false
            },
        )
    }
    if (newCategory) {
        TextPromptDialog(
            title = "New category",
            initial = "",
            confirmLabel = "Create",
            onDismiss = { newCategory = false },
            onConfirm = {
                store.createCategory(it)
                newCategory = false
            },
        )
    }
}

@Composable
private fun PlaylistCheckRow(p: Playlist, song: Song, store: LibraryStore) {
    val checked = song.id in p.songIds
    Row(
        Modifier
            .fillMaxWidth()
            .clickable { store.setSongInPlaylist(song, p.id, !checked) }
            .padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(p.name, color = Palette.Text, fontSize = 15.sp, modifier = Modifier.weight(1f))
        Checkbox(
            checked = checked,
            onCheckedChange = { store.setSongInPlaylist(song, p.id, it) },
            colors = CheckboxDefaults.colors(checkedColor = Palette.Accent, checkmarkColor = Palette.Bg),
        )
    }
}

@Composable
fun QueueSheet(ui: PlayerUi, controller: PlayerController, onDismiss: () -> Unit) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = Palette.Surface,
    ) {
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 24.dp)) {
            SectionTitle("Queue")
            Spacer(Modifier.height(8.dp))
            LazyColumn(Modifier.heightIn(max = 520.dp)) {
                itemsIndexed(ui.queue) { i, s ->
                    SongRow(
                        song = s,
                        highlighted = i == ui.index,
                        onClick = { controller.jumpTo(i) },
                        actions = emptyList(),
                    )
                }
            }
        }
    }
}
