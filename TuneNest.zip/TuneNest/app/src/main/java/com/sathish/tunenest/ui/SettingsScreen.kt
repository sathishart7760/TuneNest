package com.sathish.tunenest.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sathish.tunenest.TuneApp
import com.sathish.tunenest.data.Library
import com.sathish.tunenest.net.YouTubeApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun SettingsScreen(
    app: TuneApp,
    library: Library,
    apiKey: String,
    onApiKeyChange: (String) -> Unit,
    resumeTick: Int,
    onOpenPlaylist: (String) -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val controller = app.player
    val ui by controller.ui.collectAsState()

    var keyDraft by remember { mutableStateOf(apiKey) }
    var keySaved by remember { mutableStateOf(false) }

    val access = remember(resumeTick) { controller.ytMusic.hasAccess() }
    val ytmInstalled = remember(resumeTick) { controller.ytMusic.isInstalled() }

    var importLink by remember { mutableStateOf("") }
    var importCategory by remember { mutableStateOf<String?>(null) }
    var importing by remember { mutableStateOf(false) }
    var importResult by remember { mutableStateOf<String?>(null) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text("Settings", color = Palette.Text, fontSize = 26.sp, fontWeight = FontWeight.Bold)

        // ---- YouTube key ----
        Card {
            SectionTitle("YouTube search")
            HintText(
                "Needed to search YouTube (free). Get a key: open console.cloud.google.com → create a project → " +
                    "APIs & Services → Library → enable \"YouTube Data API v3\" → Credentials → Create credentials → API key. " +
                    "Under key restrictions choose \"Restrict key\" → YouTube Data API v3 only."
            )
            OutlinedTextField(
                value = keyDraft,
                onValueChange = {
                    keyDraft = it
                    keySaved = false
                },
                label = { Text("API key") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                colors = fieldColors(),
                modifier = Modifier.fillMaxWidth(),
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Button(
                    onClick = {
                        onApiKeyChange(keyDraft.trim())
                        keySaved = true
                    },
                    colors = accentButton(),
                ) { Text("Save key") }
                if (keySaved) Text("  Saved", color = Palette.RadioFg, fontSize = 13.sp)
                else if (apiKey.isNotBlank()) Text("  A key is saved", color = Palette.TextDim, fontSize = 13.sp)
            }
        }

        // ---- Playback ----
        Card {
            SectionTitle("YouTube playback")
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Show video", color = Palette.Text, fontSize = 15.sp)
                    HintText("Off = Poster mode: artwork here, audio in YouTube Music (background play with Premium).")
                }
                Switch(
                    checked = ui.videoMode,
                    onCheckedChange = { controller.setVideoMode(it) },
                    colors = SwitchDefaults.colors(checkedTrackColor = Palette.Accent, checkedThumbColor = Palette.Bg),
                )
            }
            StatusLine("YouTube Music app", if (ytmInstalled) "Installed" else "Not installed", ytmInstalled)
            StatusLine("Control YouTube Music", if (access) "Allowed" else "Not allowed", access)
            if (!access) {
                HintText(
                    "Poster mode needs \"Notification access\" so TuneNest can play, pause and seek YouTube Music. " +
                        "If Android says the setting is restricted, tap \"App info\", open the ⋮ menu, choose " +
                        "\"Allow restricted settings\", then try again."
                )
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = {
                            context.startActivity(
                                Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        },
                        colors = accentButton(),
                    ) { Text("Allow access") }
                    OutlinedButton(onClick = {
                        context.startActivity(
                            Intent(
                                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.fromParts("package", context.packageName, null),
                            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }) { Text("App info", color = Palette.Text) }
                }
            }
        }

        // ---- Import ----
        Card {
            SectionTitle("Import a YouTube playlist")
            HintText("Paste a public or unlisted playlist link. It becomes your own playlist here.")
            OutlinedTextField(
                value = importLink,
                onValueChange = {
                    importLink = it
                    importResult = null
                },
                label = { Text("Playlist link") },
                singleLine = true,
                colors = fieldColors(),
                modifier = Modifier.fillMaxWidth(),
            )
            if (library.categories.isNotEmpty()) {
                Text("Put it in", color = Palette.TextDim, fontSize = 13.sp)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item { Pill("No category", importCategory == null) { importCategory = null } }
                    items(library.categories) { c ->
                        Pill(c.name, importCategory == c.id) { importCategory = c.id }
                    }
                }
            }
            Button(
                enabled = !importing && importLink.isNotBlank(),
                onClick = {
                    val id = YouTubeApi.parsePlaylistId(importLink)
                    when {
                        apiKey.isBlank() -> importResult = "Save your YouTube API key first."
                        id == null -> importResult = "That doesn't look like a playlist link."
                        else -> {
                            importing = true
                            importResult = null
                            scope.launch {
                                val r = withContext(Dispatchers.IO) {
                                    runCatching {
                                        val title = YouTubeApi.playlistTitle(id, apiKey) ?: "Imported playlist"
                                        title to YouTubeApi.playlistSongs(id, apiKey)
                                    }
                                }
                                importing = false
                                r.onSuccess { (title, songs) ->
                                    if (songs.isEmpty()) {
                                        importResult = "No playable songs found in that playlist."
                                    } else {
                                        val newId = app.library.createPlaylist(title, importCategory, songs)
                                        importLink = ""
                                        importResult = "Imported ${songs.size} songs into \"$title\"."
                                        onOpenPlaylist(newId)
                                    }
                                }.onFailure {
                                    importResult = it.message ?: "Import failed."
                                }
                            }
                        }
                    }
                },
                colors = accentButton(),
            ) { Text(if (importing) "Importing…" else "Import") }
            importResult?.let { HintText(it) }
        }

        Card {
            SectionTitle("About")
            HintText(
                "TuneNest keeps your categories, playlists, likes and history on this phone only. " +
                    "YouTube songs play through YouTube's official player or the YouTube Music app."
            )
        }
    }
}

@Composable
private fun Card(content: @Composable () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Palette.Surface)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) { content() }
}

@Composable
private fun StatusLine(label: String, value: String, ok: Boolean) {
    Row {
        Text(label, color = Palette.Text, fontSize = 14.sp, modifier = Modifier.weight(1f))
        Text(value, color = if (ok) Palette.RadioFg else Palette.YouTubeFg, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Palette.Accent,
    unfocusedBorderColor = Palette.Line,
)

@Composable
private fun accentButton() = ButtonDefaults.buttonColors(containerColor = Palette.Accent, contentColor = Palette.Bg)
