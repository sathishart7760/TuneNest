@file:OptIn(ExperimentalMaterial3Api::class)

package com.sathish.tunenest.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.OndemandVideo
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.sathish.tunenest.data.Category
import com.sathish.tunenest.data.Song
import com.sathish.tunenest.data.Source

fun sourceIcon(source: Source?): ImageVector = when (source) {
    Source.YOUTUBE -> Icons.Filled.OndemandVideo
    Source.LOCAL -> Icons.Filled.PhoneAndroid
    Source.RADIO -> Icons.Filled.Radio
    null -> Icons.Filled.MusicNote
}

fun sourceLabel(source: Source): String = when (source) {
    Source.YOUTUBE -> "YouTube"
    Source.LOCAL -> "My files"
    Source.RADIO -> "Radio"
}

fun formatTime(ms: Long): String {
    val total = (ms / 1000).coerceAtLeast(0)
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}

@Composable
fun Artwork(song: Song?, modifier: Modifier = Modifier, corner: Dp = 6.dp) {
    Box(
        modifier
            .clip(RoundedCornerShape(corner))
            .background(Palette.Line),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            sourceIcon(song?.source),
            contentDescription = null,
            tint = Palette.TextDim,
            modifier = Modifier.fillMaxSize(0.42f),
        )
        if (song?.artwork != null) {
            AsyncImage(
                model = song.artwork,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.matchParentSize(),
            )
        }
    }
}

@Composable
fun SourceBadge(source: Source) {
    val (bg, fg) = when (source) {
        Source.YOUTUBE -> Palette.YouTubeBg to Palette.YouTubeFg
        Source.LOCAL -> Palette.LocalBg to Palette.LocalFg
        Source.RADIO -> Palette.RadioBg to Palette.RadioFg
    }
    Text(
        sourceLabel(source),
        color = fg,
        fontSize = 10.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(bg)
            .padding(horizontal = 6.dp, vertical = 1.dp),
    )
}

data class SongAction(val label: String, val onClick: () -> Unit)

@Composable
fun SongRow(
    song: Song,
    highlighted: Boolean,
    onClick: () -> Unit,
    actions: List<SongAction>,
    trailingText: String? = null,
) {
    var menuOpen by remember { mutableStateOf(false) }
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Artwork(song, Modifier.size(48.dp))
        Column(
            Modifier
                .weight(1f)
                .padding(start = 12.dp),
        ) {
            Text(
                song.title,
                color = if (highlighted) Palette.Accent else Palette.Text,
                fontWeight = if (highlighted) FontWeight.Bold else FontWeight.Medium,
                fontSize = 15.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(3.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                SourceBadge(song.source)
                Spacer(Modifier.width(6.dp))
                Text(
                    song.artist,
                    color = Palette.TextDim,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
        val trailing = trailingText ?: when {
            song.source == Source.RADIO -> "LIVE"
            song.durationMs > 0 -> formatTime(song.durationMs)
            else -> null
        }
        if (trailing != null) {
            Text(
                trailing,
                color = if (trailing == "LIVE") Palette.RadioFg else Palette.TextDim,
                fontSize = 12.sp,
            )
        }
        if (actions.isNotEmpty()) {
            Box {
                IconButton(onClick = { menuOpen = true }) {
                    Icon(Icons.Filled.MoreVert, contentDescription = "Song options", tint = Palette.TextDim)
                }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    actions.forEach { a ->
                        DropdownMenuItem(
                            text = { Text(a.label) },
                            onClick = {
                                menuOpen = false
                                a.onClick()
                            },
                        )
                    }
                }
            }
        }
    }
}

/** 2x2 mosaic of the first four songs, or a single artwork. */
@Composable
fun PlaylistCover(songs: List<Song>, size: Dp, corner: Dp = 8.dp) {
    val withArt = songs.filter { it.artwork != null }.distinctBy { it.artwork }
    if (withArt.size >= 4) {
        Column(
            Modifier
                .size(size)
                .clip(RoundedCornerShape(corner)),
        ) {
            Row(Modifier.weight(1f)) {
                Artwork(withArt[0], Modifier.weight(1f).fillMaxSize(), corner = 0.dp)
                Artwork(withArt[1], Modifier.weight(1f).fillMaxSize(), corner = 0.dp)
            }
            Row(Modifier.weight(1f)) {
                Artwork(withArt[2], Modifier.weight(1f).fillMaxSize(), corner = 0.dp)
                Artwork(withArt[3], Modifier.weight(1f).fillMaxSize(), corner = 0.dp)
            }
        }
    } else {
        Artwork(songs.firstOrNull(), Modifier.size(size), corner = corner)
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(
        text,
        color = Palette.Text,
        fontSize = 18.sp,
        fontWeight = FontWeight.Bold,
        modifier = modifier,
    )
}

@Composable
fun HintText(text: String, modifier: Modifier = Modifier) {
    Text(text, color = Palette.TextDim, fontSize = 14.sp, modifier = modifier)
}

@Composable
fun TextPromptDialog(
    title: String,
    initial: String,
    confirmLabel: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit,
) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
        },
        confirmButton = {
            TextButton(
                enabled = text.isNotBlank(),
                onClick = { onConfirm(text.trim()) },
            ) { Text(confirmLabel) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
        containerColor = Palette.Surface,
    )
}

@Composable
fun CategoryPickerDialog(
    categories: List<Category>,
    selected: String?,
    onDismiss: () -> Unit,
    onPick: (String?) -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Move to category") },
        text = {
            LazyColumn {
                item {
                    CategoryOption("No category", selected == null) { onPick(null) }
                }
                items(categories) { c ->
                    CategoryOption(c.name, selected == c.id) { onPick(c.id) }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
        containerColor = Palette.Surface,
    )
}

@Composable
private fun CategoryOption(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = onClick)
        Text(label, color = Palette.Text)
    }
}

@Composable
fun NewPlaylistDialog(
    categories: List<Category>,
    initialCategoryId: String?,
    onDismiss: () -> Unit,
    onCreate: (name: String, categoryId: String?) -> Unit,
) {
    var name by remember { mutableStateOf("") }
    var categoryId by remember { mutableStateOf(initialCategoryId) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New playlist") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Playlist name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                if (categories.isNotEmpty()) {
                    Text("Category", color = Palette.TextDim, fontSize = 13.sp)
                    LazyColumn(Modifier.height((48 * (categories.size + 1)).coerceAtMost(220).dp)) {
                        item { CategoryOption("No category", categoryId == null) { categoryId = null } }
                        items(categories) { c ->
                            CategoryOption(c.name, categoryId == c.id) { categoryId = c.id }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = name.isNotBlank(), onClick = { onCreate(name.trim(), categoryId) }) {
                Text("Create")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
        containerColor = Palette.Surface,
    )
}

@Composable
fun Pill(text: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        text,
        color = if (selected) Palette.Bg else Palette.Text,
        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
        fontSize = 14.sp,
        modifier = Modifier
            .clip(RoundedCornerShape(18.dp))
            .background(if (selected) Palette.Accent else Palette.Surface)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 9.dp),
    )
}

val Transparent = Color.Transparent
