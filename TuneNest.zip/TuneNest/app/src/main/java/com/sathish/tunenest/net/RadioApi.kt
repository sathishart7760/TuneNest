package com.sathish.tunenest.net

import com.sathish.tunenest.data.Song
import com.sathish.tunenest.data.Source
import org.json.JSONArray
import java.io.IOException

/** radio-browser.info — free directory of internet radio stations. */
object RadioApi {
    private val hosts = listOf(
        "de1.api.radio-browser.info",
        "nl1.api.radio-browser.info",
        "at1.api.radio-browser.info",
        "fi1.api.radio-browser.info",
    )

    /** Blank [name] returns the most popular stations in [countryCode]. */
    fun search(name: String, countryCode: String = "IN"): List<Song> {
        val path = buildString {
            append("/json/stations/search?limit=50&hidebroken=true&order=clickcount&reverse=true")
            if (name.isNotBlank()) append("&name=${Http.enc(name)}") else append("&countrycode=$countryCode")
        }
        var last: Exception? = null
        for (host in hosts) {
            try {
                return parse(Http.get("https://$host$path"))
            } catch (e: Exception) {
                last = e
            }
        }
        throw last ?: IOException("Radio directory unavailable")
    }

    private fun parse(body: String): List<Song> {
        val arr = JSONArray(body)
        val out = mutableListOf<Song>()
        val seen = HashSet<String>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val url = o.optString("url_resolved").ifBlank { o.optString("url") }.trim()
            if (url.isBlank() || !seen.add(url)) continue
            val tag = o.optString("tags").split(",").map { it.trim() }.firstOrNull { it.isNotBlank() }
            out += Song(
                source = Source.RADIO,
                ref = url,
                title = o.optString("name").trim().ifBlank { "Radio station" },
                artist = (tag ?: o.optString("country")).ifBlank { "Live radio" }
                    .replaceFirstChar { it.uppercase() },
                artwork = o.optString("favicon").takeIf { it.startsWith("http") },
            )
        }
        return out
    }
}
