package com.sathish.tunenest.ui

import android.graphics.Bitmap
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import androidx.palette.graphics.Palette as ColorPalette
import coil.compose.AsyncImage
import coil.compose.rememberAsyncImagePainter
import coil.imageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import com.sathish.tunenest.data.Library
import com.sathish.tunenest.data.Song
import com.sathish.tunenest.data.Source
import com.sathish.tunenest.net.YouTubeApi
import com.sathish.tunenest.playback.Engine
import com.sathish.tunenest.playback.PlayerController
import com.sathish.tunenest.playback.PlayerUi
import com.sathish.tunenest.playback.RepeatMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Background color taken from the artwork, darkened so white text stays readable. */
@Composable
fun rememberArtColor(model: Any?, fallback: Color): Color {
    val context = LocalContext.current
    var color by remember { mutableStateOf(fallback) }
    LaunchedEffect(model) {
        if (model == null) {
            color = fallback
            return@LaunchedEffect
        }
        val bitmap: Bitmap? = if (model is Bitmap) model else withContext(Dispatchers.IO) {
            try {
                val request = ImageRequest.Builder(context)
                    .data(model)
                    .allowHardware(false)
                    .size(128)
                    .build()
                (context.imageLoader.execute(request) as? SuccessResult)?.drawable?.toBitmap()
            } catch (e: Exception) {
                null
            }
        }
        if (bitmap != null) {
            val p = withContext(Dispatchers.Default) { ColorPalette.from(bitmap).generate() }
            val argb = p.getDarkVibrantColor(p.getDarkMutedColor(p.getMutedColor(0xFF3A2A26.toInt())))
            var c = Color(argb)
            while (c.luminance() > 0.12f) c = lerp(c, Color.Black, 0.25f)
            color = c
        }
    }
    return animateColorAsState(color, label = "artColor").value
}

@Composable
fun NowPlayingScreen(
    ui: PlayerUi,
    library: Library,
    controller: PlayerController,
    onToggleLike: (Song) -> Unit,
    onAddToPlaylist: (Song) -> Unit,
    onShowQueue: () -> Unit,
    onClose: () -> Unit,
    onVideoSlot: (Rect) -> Unit,
) {
    val song = ui.current ?: return
    val isYouTube = song.source == Source.YOUTUBE
    val posterModel: Any? = when {
        ui.engine == Engine.YT_MUSIC && ui.posterArt != null -> ui.posterArt
        isYouTube -> YouTubeApi.posterThumbnail(song.ref)
        else -> song.artwork
    }
    val bg = rememberArtColor(posterModel ?: song.artwork, Color(0xFF3A2A26))
    val liked = song.id in library.liked
    var closing by remember { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .background(bg)
            .pointerInput(Unit) { detectTapGestures { } }
            .padding(horizontal = 24.dp),
    ) {
        // Grabber: tap or drag down to close.
        Box(
            Modifier
                .fillMaxWidth()
                .height(40.dp)
                .pointerInput(Unit) {
                    detectVerticalDragGestures { _, dragAmount ->
                        if (dragAmount > 20 && !closing) {
                            closing = true
                            onClose()
                        }
                    }
                }
                .clickable { onClose() },
            contentAlignment = Alignment.Center,
        ) {
            Box(
                Modifier
                    .size(width = 40.dp, height = 5.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(Color.White.copy(alpha = 0.45f))
            )
        }

        // Artwork / video
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentAlignment = Alignment.Center,
        ) {
            if (ui.engine == Engine.YT_EMBED) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .aspectRatio(16f / 9f)
                        .shadow(18.dp, RoundedCornerShape(12.dp))
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.Black)
                        .onGloballyPositioned { onVideoSlot(it.boundsInRoot()) },
                    contentAlignment = Alignment.Center,
                ) {
                    CircularProgressIndicator(color = Color.White.copy(alpha = 0.5f), strokeWidth = 2.dp)
                }
            } else {
                Box(
                    Modifier
                        .padding(vertical = 8.dp)
                        .aspectRatio(1f)
                        .shadow(18.dp, RoundedCornerShape(12.dp))
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.Black.copy(alpha = 0.25f)),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        Icons.Filled.MusicNote,
                        contentDescription = null,
                        tint = Color.White.copy(alpha = 0.4f),
                        modifier = Modifier.size(72.dp),
                    )
                    when {
                        posterModel is Bitmap -> Image(
                            bitmap = posterModel.asImageBitmap(),
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize(),
                        )
                        posterModel != null -> AsyncImage(
                            model = posterModel,
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            error = if (isYouTube) rememberAsyncImagePainter(song.artwork) else null,
                            modifier = Modifier.fillMaxSize(),
                        )
                    }
                }
            }
        }

        // Video | Poster switch for YouTube songs
        if (isYouTube) {
            Spacer(Modifier.height(14.dp))
            Row(
                Modifier
                    .align(Alignment.CenterHorizontally)
                    .clip(RoundedCornerShape(18.dp))
                    .background(Color.Black.copy(alpha = 0.25f))
                    .padding(3.dp),
            ) {
                ModeButton("Video", ui.videoMode) { controller.setVideoMode(true) }
                ModeButton("Poster", !ui.videoMode) { controller.setVideoMode(false) }
            }
            if (ui.engine == Engine.YT_MUSIC) {
                Row(
                    Modifier
                        .align(Alignment.CenterHorizontally)
                        .padding(top = 6.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { controller.openYtMusic() }
                        .padding(horizontal = 10.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("Audio is playing in YouTube Music", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
                    Spacer(Modifier.width(4.dp))
                    Icon(Icons.Filled.OpenInNew, contentDescription = "Open YouTube Music", tint = Color.White.copy(alpha = 0.7f), modifier = Modifier.size(14.dp))
                }
            }
        }

        ui.message?.let {
            Text(
                it,
                color = Color.White.copy(alpha = 0.85f),
                fontSize = 13.sp,
                modifier = Modifier
                    .padding(top = 10.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.Black.copy(alpha = 0.3f))
                    .clickable { controller.clearMessage() }
                    .padding(10.dp),
            )
        }

        Spacer(Modifier.height(22.dp))

        // Title row
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    song.title,
                    color = Color.White,
                    fontSize = 21.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    song.artist,
                    color = Color.White.copy(alpha = 0.7f),
                    fontSize = 18.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            RoundIcon(
                if (liked) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                if (liked) "Unlike" else "Like",
            ) { onToggleLike(song) }
            Spacer(Modifier.width(10.dp))
            RoundIcon(Icons.Filled.MoreHoriz, "Add to playlist") { onAddToPlaylist(song) }
        }

        Spacer(Modifier.height(18.dp))

        // Progress
        if (song.source == Source.RADIO) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(Palette.RadioFg)
                )
                Spacer(Modifier.width(8.dp))
                Text("LIVE", color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(20.dp))
        } else {
            var dragging by remember { mutableStateOf<Float?>(null) }
            val duration = ui.durationMs.coerceAtLeast(1L)
            val fraction = dragging ?: (ui.positionMs.toFloat() / duration).coerceIn(0f, 1f)
            Slider(
                value = fraction,
                onValueChange = { dragging = it },
                onValueChangeFinished = {
                    dragging?.let { controller.seekTo((it * duration).toLong()) }
                    dragging = null
                },
                colors = SliderDefaults.colors(
                    thumbColor = Color.White,
                    activeTrackColor = Color.White.copy(alpha = 0.85f),
                    inactiveTrackColor = Color.White.copy(alpha = 0.22f),
                ),
            )
            val shownPos = ((dragging ?: 0f) * duration).toLong().takeIf { dragging != null } ?: ui.positionMs
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(formatTime(shownPos), color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
                Text(
                    if (ui.durationMs > 0) "-" + formatTime(ui.durationMs - shownPos) else "--:--",
                    color = Color.White.copy(alpha = 0.6f),
                    fontSize = 12.sp,
                )
            }
        }

        Spacer(Modifier.height(10.dp))

        // Main controls
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = { controller.previous() }, modifier = Modifier.size(64.dp)) {
                Icon(Icons.Filled.SkipPrevious, contentDescription = "Previous", tint = Color.White, modifier = Modifier.size(44.dp))
            }
            IconButton(onClick = { controller.togglePlayPause() }, modifier = Modifier.size(80.dp)) {
                if (ui.isBuffering && !ui.isPlaying) {
                    CircularProgressIndicator(color = Color.White, strokeWidth = 3.dp, modifier = Modifier.size(44.dp))
                } else {
                    Icon(
                        if (ui.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        contentDescription = if (ui.isPlaying) "Pause" else "Play",
                        tint = Color.White,
                        modifier = Modifier.size(60.dp),
                    )
                }
            }
            IconButton(onClick = { controller.next() }, modifier = Modifier.size(64.dp)) {
                Icon(Icons.Filled.SkipNext, contentDescription = "Next", tint = Color.White, modifier = Modifier.size(44.dp))
            }
        }

        Spacer(Modifier.height(14.dp))

        // Bottom row
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
            IconButton(onClick = { controller.toggleShuffle() }) {
                Icon(
                    Icons.Filled.Shuffle,
                    contentDescription = "Shuffle",
                    tint = if (ui.shuffle) Palette.Accent else Color.White.copy(alpha = 0.75f),
                )
            }
            IconButton(onClick = { controller.cycleRepeat() }) {
                Icon(
                    if (ui.repeat == RepeatMode.ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                    contentDescription = "Repeat",
                    tint = if (ui.repeat != RepeatMode.OFF) Palette.Accent else Color.White.copy(alpha = 0.75f),
                )
            }
            IconButton(onClick = onShowQueue) {
                Icon(Icons.Filled.QueueMusic, contentDescription = "Queue", tint = Color.White.copy(alpha = 0.75f))
            }
        }
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun ModeButton(label: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        label,
        color = Color.White,
        fontSize = 13.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (selected) Color.White.copy(alpha = 0.28f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 7.dp),
    )
}

@Composable
private fun RoundIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, description: String, onClick: () -> Unit) {
    Box(
        Modifier
            .size(38.dp)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.14f))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription = description, tint = Color.White, modifier = Modifier.size(20.dp))
    }
}

@Composable
fun MiniPlayer(
    ui: PlayerUi,
    controller: PlayerController,
    onOpen: () -> Unit,
    onVideoSlot: (Rect) -> Unit,
) {
    val song = ui.current ?: return
    val fraction = if (ui.durationMs > 0) (ui.positionMs.toFloat() / ui.durationMs).coerceIn(0f, 1f) else 0f
    Column(
        Modifier
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Palette.Surface2),
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (ui.engine == Engine.YT_EMBED) {
                // The real YouTube player is drawn on top of this box.
                Box(
                    Modifier
                        .size(width = 144.dp, height = 81.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color.Black)
                        .onGloballyPositioned { onVideoSlot(it.boundsInRoot()) }
                )
            } else {
                Artwork(song, Modifier.size(44.dp))
            }
            Column(
                Modifier
                    .weight(1f)
                    .clickable(onClick = onOpen)
                    .padding(horizontal = 12.dp, vertical = 4.dp),
            ) {
                Text(
                    song.title,
                    color = Palette.Text,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    "${song.artist} · ${sourceLabel(song.source)}",
                    color = Palette.TextDim,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            IconButton(onClick = { controller.togglePlayPause() }) {
                if (ui.isBuffering && !ui.isPlaying) {
                    CircularProgressIndicator(color = Palette.Text, strokeWidth = 2.dp, modifier = Modifier.size(22.dp))
                } else {
                    Icon(
                        if (ui.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        contentDescription = if (ui.isPlaying) "Pause" else "Play",
                        tint = Palette.Text,
                    )
                }
            }
            IconButton(onClick = { controller.next() }) {
                Icon(Icons.Filled.SkipNext, contentDescription = "Next", tint = Palette.Text)
            }
        }
        Box(
            Modifier
                .fillMaxWidth()
                .height(2.dp)
                .background(Palette.Line)
        ) {
            Box(
                Modifier
                    .fillMaxWidth(fraction)
                    .fillMaxHeight()
                    .background(Palette.Accent)
            )
        }
    }
}
