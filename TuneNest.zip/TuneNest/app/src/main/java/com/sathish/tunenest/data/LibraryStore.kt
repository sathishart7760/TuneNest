package com.sathish.tunenest.data

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONObject
import java.io.File
import java.util.UUID

/** Your library (categories, playlists, likes, history), saved as JSON on the phone. */
class LibraryStore(private val file: File) {

    private val _state = MutableStateFlow(load())
    val state: StateFlow<Library> = _state.asStateFlow()
    val value: Library get() = _state.value

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val saveLock = Mutex()

    private fun load(): Library = try {
        if (file.exists()) Library.fromJson(JSONObject(file.readText())) else Library()
    } catch (e: Exception) {
        Library()
    }

    private fun commit(transform: (Library) -> Library) {
        _state.update(transform)
        scope.launch {
            saveLock.withLock {
                val snapshot = _state.value
                val tmp = File(file.parentFile, file.name + ".tmp")
                tmp.writeText(snapshot.toJson().toString())
                if (!tmp.renameTo(file)) {
                    file.writeText(tmp.readText())
                    tmp.delete()
                }
            }
        }
    }

    private fun newId() = UUID.randomUUID().toString()

    // ---- Categories ----

    fun createCategory(name: String): String {
        val id = newId()
        commit { it.copy(categories = it.categories + Category(id, name.trim())) }
        return id
    }

    fun renameCategory(id: String, name: String) = commit { l ->
        l.copy(categories = l.categories.map { if (it.id == id) it.copy(name = name.trim()) else it })
    }

    fun deleteCategory(id: String) = commit { l ->
        l.copy(
            categories = l.categories.filterNot { it.id == id },
            playlists = l.playlists.map { if (it.categoryId == id) it.copy(categoryId = null) else it },
        )
    }

    // ---- Playlists ----

    fun createPlaylist(name: String, categoryId: String?, songs: List<Song> = emptyList()): String {
        val id = newId()
        commit { l ->
            l.copy(
                songs = l.songs + songs.associateBy { it.id },
                playlists = l.playlists + Playlist(id, name.trim(), categoryId, songs.map { it.id }.distinct()),
            )
        }
        return id
    }

    fun renamePlaylist(id: String, name: String) = commit { l ->
        l.copy(playlists = l.playlists.map { if (it.id == id) it.copy(name = name.trim()) else it })
    }

    fun movePlaylist(id: String, categoryId: String?) = commit { l ->
        l.copy(playlists = l.playlists.map { if (it.id == id) it.copy(categoryId = categoryId) else it })
    }

    fun deletePlaylist(id: String) = commit { l ->
        l.copy(playlists = l.playlists.filterNot { it.id == id })
    }

    fun setSongInPlaylist(song: Song, playlistId: String, include: Boolean) = commit { l ->
        l.copy(
            songs = l.songs + (song.id to song),
            playlists = l.playlists.map { p ->
                if (p.id != playlistId) p
                else if (include) {
                    if (song.id in p.songIds) p else p.copy(songIds = p.songIds + song.id)
                } else {
                    p.copy(songIds = p.songIds - song.id)
                }
            },
        )
    }

    fun removeFromPlaylist(playlistId: String, songId: String) = commit { l ->
        l.copy(playlists = l.playlists.map { if (it.id == playlistId) it.copy(songIds = it.songIds - songId) else it })
    }

    // ---- Likes & history ----

    fun toggleLike(song: Song) = commit { l ->
        if (song.id in l.liked) l.copy(liked = l.liked - song.id)
        else l.copy(songs = l.songs + (song.id to song), liked = listOf(song.id) + l.liked)
    }

    fun recordPlay(song: Song) = commit { l ->
        l.copy(
            songs = l.songs + (song.id to song),
            history = (listOf(HistoryEntry(song.id, System.currentTimeMillis())) + l.history).take(1000),
        )
    }
}
