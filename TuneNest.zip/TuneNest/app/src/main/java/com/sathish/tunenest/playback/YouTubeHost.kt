package com.sathish.tunenest.playback

import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.PlayerConstants
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener

/** Talks to the official YouTube embedded player shown inside the app. */
class YouTubeHost(private val controller: PlayerController) {

    private var player: YouTubePlayer? = null
    private var pending: Pair<String, Float>? = null
    private var currentId: String? = null
    private var lastSecond: Float = 0f

    val listener = object : AbstractYouTubePlayerListener() {
        override fun onReady(youTubePlayer: YouTubePlayer) {
            player = youTubePlayer
            val p = pending
            val id = currentId
            if (p != null) {
                youTubePlayer.loadVideo(p.first, p.second)
                currentId = p.first
                pending = null
            } else if (id != null) {
                // The screen was recreated: put the last video back, paused.
                youTubePlayer.cueVideo(id, lastSecond)
            }
        }

        override fun onStateChange(youTubePlayer: YouTubePlayer, state: PlayerConstants.PlayerState) {
            controller.onYouTubeState(state)
        }

        override fun onCurrentSecond(youTubePlayer: YouTubePlayer, second: Float) {
            lastSecond = second
            controller.onYouTubeProgress((second * 1000).toLong())
        }

        override fun onVideoDuration(youTubePlayer: YouTubePlayer, duration: Float) {
            controller.onYouTubeDuration((duration * 1000).toLong())
        }

        override fun onError(youTubePlayer: YouTubePlayer, error: PlayerConstants.PlayerError) {
            controller.onYouTubeError(error)
        }
    }

    fun load(videoId: String, startSeconds: Float) {
        lastSecond = startSeconds
        val p = player
        if (p == null) {
            pending = videoId to startSeconds
            currentId = videoId
        } else {
            p.loadVideo(videoId, startSeconds)
            currentId = videoId
        }
    }

    fun play() {
        player?.play()
    }

    fun pause() {
        player?.pause()
    }

    fun seekTo(seconds: Float) {
        player?.seekTo(seconds)
    }

    fun onViewReleased() {
        player = null
    }
}
