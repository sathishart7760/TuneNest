package com.sathish.tunenest.net

import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object Http {
    fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15_000
        c.readTimeout = 20_000
        c.setRequestProperty("User-Agent", "TuneNest/1.0 (Android)")
        try {
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) throw IOException(errorMessage(body) ?: "Request failed (HTTP $code)")
            return body
        } finally {
            c.disconnect()
        }
    }

    private fun errorMessage(body: String): String? = try {
        JSONObject(body).getJSONObject("error").optString("message").takeIf { it.isNotBlank() }
    } catch (e: Exception) {
        null
    }

    fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")
}
