package com.sathish.tunenest.playback

import android.service.notification.NotificationListenerService

/**
 * Empty on purpose. Having "notification access" lets the app see and control
 * YouTube Music's player (play/pause/seek) for Poster mode. It does not read your notifications.
 */
class MediaListenerService : NotificationListenerService()
