package com.sathish.tunenest.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.mutableIntStateOf
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.options.IFramePlayerOptions
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView
import com.sathish.tunenest.R
import com.sathish.tunenest.tuneApp

class MainActivity : ComponentActivity() {

    private val resumeTick = mutableIntStateOf(0)
    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = tuneApp

        // One official YouTube player for the whole app. It pauses itself when the app goes to the background.
        val ytView = layoutInflater.inflate(R.layout.yt_player, null) as YouTubePlayerView
        lifecycle.addObserver(ytView)
        ytView.initialize(
            app.player.youtube.listener,
            IFramePlayerOptions.Builder(this)
                .controls(0)
                .rel(0)
                .ivLoadPolicy(3)
                .build(),
        )

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            TuneTheme {
                AppRoot(app = app, ytView = ytView, resumeTick = resumeTick.intValue)
            }
        }
    }

    override fun onStart() {
        super.onStart()
        tuneApp.player.appVisible = true
    }

    override fun onStop() {
        tuneApp.player.appVisible = false
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        resumeTick.intValue = resumeTick.intValue + 1
    }

    override fun onDestroy() {
        tuneApp.player.youtube.onViewReleased()
        super.onDestroy()
    }
}
