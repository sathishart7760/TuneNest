package com.sathish.tunenest.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sathish.tunenest.data.Category
import com.sathish.tunenest.data.Library
import com.sathish.tunenest.data.LibraryStore
import com.sathish.tunenest.data.Playlist

@Composable
fun LibraryScreen(
    library: Library,
    store: LibraryStore,
    filter: String?,
    onFilter: (String?) -> Unit,
    onOpenPlaylist: (String) -> Unit,
    onOpenSmart: (SmartKind) -> Unit,
) {
    var addMenu by remember { mutableStateOf(false) }
    var newPlaylistIn by remember { mutableStateOf<String?>(null) }
    var showNewPlaylist by remember { mutableStateOf(false) }
    var showNewCategory by remember { mutableStateOf(false) }
    var renameCategory by remember { mutableStateOf<Category?>(null) }
    var deleteCategory by remember { mutableStateOf<Category?>(null) }

    val selected = library.categories.firstOrNull { it.id == filter }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Your Library",
                    color = Palette.Text,
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f),
                )
                Box {
                    IconButton(onClick = { addMenu = true }) {
                        Icon(Icons.Filled.Add, contentDescription = "Create", tint = Palette.Text)
                    }
                    DropdownMenu(expanded = addMenu, onDismissRequest = { addMenu = false }) {
                        DropdownMenuItem(text = { Text("New playlist") }, onClick = {
                            addMenu = false
                            newPlaylistIn = filter
                            showNewPlaylist = true
                        })
                        DropdownMenuItem(text = { Text("New category") }, onClick = {
                            addMenu = false
                            showNewCategory = true
                        })
                    }
                }
            }
        }

        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item { Pill("All", filter == null) { onFilter(null) } }
                items(library.categories) { c ->
                    Pill(c.name, filter == c.id) { onFilter(c.id) }
                }
            }
        }

        if (selected == null) {
            item {
                LikedCard(count = library.liked.size) { onOpenSmart(SmartKind.LIKED) }
            }

            if (library.categories.isNotEmpty()) {
                item { SectionTitle("Your categories") }
                val rows = library.categories.chunked(2)
                items(rows) { pair ->
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        pair.forEach { c ->
                            val idx = library.categories.indexOf(c)
                            CategoryCard(
                                category = c,
                                count = library.playlistsIn(c.id).size,
                                colors = Palette.categoryColors[idx % Palette.categoryColors.size],
                                modifier = Modifier.weight(1f),
                            ) { onFilter(c.id) }
                        }
                        if (pair.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            } else {
                item {
                    HintText("Make categories like Tamil, Workout or Chill with the + button, then put playlists inside them.")
                }
            }

            item { SectionTitle("Playlists") }
            if (library.playlists.isEmpty()) {
                item { HintText("No playlists yet. Tap + to create one, or import a YouTube playlist in Settings.") }
            } else {
                items(library.playlists) { p ->
                    PlaylistRow(p, library) { onOpenPlaylist(p.id) }
                }
            }

            item { SectionTitle("Smart playlists") }
            item {
                SmartRow(Icons.Filled.History, "Recently Played", "Updates as you listen") { onOpenSmart(SmartKind.RECENT) }
            }
            item {
                SmartRow(Icons.Filled.TrendingUp, "Most Played", "Your top songs from the last 30 days") { onOpenSmart(SmartKind.MOST) }
            }
        } else {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        selected.name,
                        color = Palette.Text,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f),
                    )
                    TextButton(onClick = { renameCategory = selected }) { Text("Rename") }
                    TextButton(onClick = { deleteCategory = selected }) { Text("Delete") }
                }
            }
            val inCat = library.playlistsIn(selected.id)
            if (inCat.isEmpty()) {
                item { HintText("No playlists in ${selected.name} yet.") }
            }
            items(inCat) { p -> PlaylistRow(p, library) { onOpenPlaylist(p.id) } }
            item {
                TextButton(onClick = {
                    newPlaylistIn = selected.id
                    showNewPlaylist = true
                }) {
                    Icon(Icons.Filled.Add, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("New playlist in ${selected.name}")
                }
            }
        }
    }

    if (showNewPlaylist) {
        NewPlaylistDialog(
            categories = library.categories,
            initialCategoryId = newPlaylistIn,
            onDismiss = { showNewPlaylist = false },
            onCreate = { name, catId ->
                val id = store.createPlaylist(name, catId)
                showNewPlaylist = false
                onOpenPlaylist(id)
            },
        )
    }
    if (showNewCategory) {
        TextPromptDialog(
            title = "New category",
            initial = "",
            confirmLabel = "Create",
            onDismiss = { showNewCategory = false },
            onConfirm = {
                val id = store.createCategory(it)
                showNewCategory = false
                onFilter(id)
            },
        )
    }
    renameCategory?.let { c ->
        TextPromptDialog(
            title = "Rename category",
            initial = c.name,
            confirmLabel = "Save",
            onDismiss = { renameCategory = null },
            onConfirm = {
                store.renameCategory(c.id, it)
                renameCategory = null
            },
        )
    }
    deleteCategory?.let { c ->
        AlertDialog(
            onDismissRequest = { deleteCategory = null },
            title = { Text("Delete ${c.name}?") },
            text = { Text("Its playlists stay in your library without a category.") },
            confirmButton = {
                TextButton(onClick = {
                    store.deleteCategory(c.id)
                    deleteCategory = null
                    onFilter(null)
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { deleteCategory = null }) { Text("Cancel") } },
            containerColor = Palette.Surface,
        )
    }
}

@Composable
private fun LikedCard(count: Int, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Palette.Surface)
            .clickable(onClick = onClick)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(56.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xFF5B4BDB)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Filled.Favorite, contentDescription = null, tint = Color.White, modifier = Modifier.size(26.dp))
        }
        Column(Modifier.padding(start = 14.dp)) {
            Text("Liked Songs", color = Palette.Text, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text("$count songs", color = Palette.TextDim, fontSize = 13.sp)
        }
    }
}

@Composable
private fun CategoryCard(
    category: Category,
    count: Int,
    colors: Pair<Color, Color>,
    modifier: Modifier,
    onClick: () -> Unit,
) {
    Column(
        modifier
            .clip(RoundedCornerShape(14.dp))
            .background(colors.first)
            .clickable(onClick = onClick)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Icon(Icons.Filled.Folder, contentDescription = null, tint = colors.second, modifier = Modifier.size(22.dp))
        Text(
            category.name,
            color = Palette.Text,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Text(if (count == 1) "1 playlist" else "$count playlists", color = Palette.TextDim, fontSize = 12.sp)
    }
}

@Composable
fun PlaylistRow(p: Playlist, library: Library, onClick: () -> Unit) {
    val songs = library.songsOf(p.songIds)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        PlaylistCover(songs, 52.dp)
        Column(Modifier.padding(start = 12.dp)) {
            Text(p.name, color = Palette.Text, fontWeight = FontWeight.Medium, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            val cat = library.categoryName(p.categoryId)
            Text(
                listOfNotNull("${songs.size} songs", cat).joinToString("  ·  "),
                color = Palette.TextDim,
                fontSize = 13.sp,
            )
        }
    }
}

@Composable
private fun SmartRow(icon: ImageVector, title: String, subtitle: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Palette.Line),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, contentDescription = null, tint = Palette.Text)
        }
        Column(Modifier.padding(start = 12.dp)) {
            Text(title, color = Palette.Text, fontWeight = FontWeight.Medium, fontSize = 15.sp)
            Text(subtitle, color = Palette.TextDim, fontSize = 13.sp)
        }
    }
    Spacer(Modifier.height(0.dp))
}
