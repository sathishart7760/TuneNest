package com.sathish.tunenest.data

import org.json.JSONArray
import org.json.JSONObject

enum class Source { YOUTUBE, LOCAL, RADIO }

/** One playable item. [ref] is a YouTube video id, a local content:// uri, or a radio stream url. */
data class Song(
    val source: Source,
    val ref: String,
    val title: String,
    val artist: String,
    val artwork: String?,
    val durationMs: Long = 0L,
) {
    val id: String get() = "${source.name}:$ref"

    fun toJson(): JSONObject = JSONObject()
        .put("source", source.name)
        .put("ref", ref)
        .put("title", title)
        .put("artist", artist)
        .put("artwork", artwork ?: JSONObject.NULL)
        .put("durationMs", durationMs)

    companion object {
        fun fromJson(o: JSONObject): Song = Song(
            source = Source.valueOf(o.getString("source")),
            ref = o.getString("ref"),
            title = o.optString("title"),
            artist = o.optString("artist"),
            artwork = if (o.isNull("artwork")) null else o.optString("artwork"),
            durationMs = o.optLong("durationMs"),
        )
    }
}

data class Category(val id: String, val name: String)

data class Playlist(
    val id: String,
    val name: String,
    val categoryId: String?,
    val songIds: List<String>,
)

data class HistoryEntry(val songId: String, val at: Long)

data class Library(
    val songs: Map<String, Song> = emptyMap(),
    val categories: List<Category> = emptyList(),
    val playlists: List<Playlist> = emptyList(),
    val liked: List<String> = emptyList(),
    val history: List<HistoryEntry> = emptyList(),
) {
    fun songsOf(ids: List<String>): List<Song> = ids.mapNotNull { songs[it] }

    fun likedSongs(): List<Song> = songsOf(liked)

    fun recentSongs(): List<Song> =
        songsOf(history.map { it.songId }.distinct().take(50))

    fun mostPlayed(): List<Song> {
        val since = System.currentTimeMillis() - 30L * 24 * 60 * 60 * 1000
        return history.filter { it.at >= since }
            .groupingBy { it.songId }
            .eachCount()
            .entries
            .sortedByDescending { it.value }
            .take(50)
            .mapNotNull { songs[it.key] }
    }

    fun playlistsIn(categoryId: String?): List<Playlist> =
        playlists.filter { it.categoryId == categoryId }

    fun categoryName(id: String?): String? = categories.firstOrNull { it.id == id }?.name

    fun toJson(): JSONObject {
        val songsArr = JSONArray()
        songs.values.forEach { songsArr.put(it.toJson()) }
        val catArr = JSONArray()
        categories.forEach { catArr.put(JSONObject().put("id", it.id).put("name", it.name)) }
        val plArr = JSONArray()
        playlists.forEach { p ->
            plArr.put(
                JSONObject()
                    .put("id", p.id)
                    .put("name", p.name)
                    .put("categoryId", p.categoryId ?: JSONObject.NULL)
                    .put("songIds", JSONArray(p.songIds))
            )
        }
        val histArr = JSONArray()
        history.forEach { histArr.put(JSONObject().put("songId", it.songId).put("at", it.at)) }
        return JSONObject()
            .put("version", 1)
            .put("songs", songsArr)
            .put("categories", catArr)
            .put("playlists", plArr)
            .put("liked", JSONArray(liked))
            .put("history", histArr)
    }

    companion object {
        fun fromJson(o: JSONObject): Library {
            val songs = LinkedHashMap<String, Song>()
            o.optJSONArray("songs")?.let { a ->
                for (i in 0 until a.length()) {
                    runCatching { Song.fromJson(a.getJSONObject(i)) }.getOrNull()?.let { songs[it.id] = it }
                }
            }
            val categories = mutableListOf<Category>()
            o.optJSONArray("categories")?.let { a ->
                for (i in 0 until a.length()) {
                    val c = a.getJSONObject(i)
                    categories += Category(c.getString("id"), c.optString("name"))
                }
            }
            val playlists = mutableListOf<Playlist>()
            o.optJSONArray("playlists")?.let { a ->
                for (i in 0 until a.length()) {
                    val p = a.getJSONObject(i)
                    playlists += Playlist(
                        id = p.getString("id"),
                        name = p.optString("name"),
                        categoryId = if (p.isNull("categoryId")) null else p.optString("categoryId"),
                        songIds = p.optJSONArray("songIds").toStringList(),
                    )
                }
            }
            val history = mutableListOf<HistoryEntry>()
            o.optJSONArray("history")?.let { a ->
                for (i in 0 until a.length()) {
                    val h = a.getJSONObject(i)
                    history += HistoryEntry(h.getString("songId"), h.optLong("at"))
                }
            }
            return Library(
                songs = songs,
                categories = categories,
                playlists = playlists,
                liked = o.optJSONArray("liked").toStringList(),
                history = history,
            )
        }

        private fun JSONArray?.toStringList(): List<String> {
            if (this == null) return emptyList()
            return (0 until length()).map { getString(it) }
        }
    }
}
