package com.sathish.tunenest.ui

import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sathish.tunenest.data.Library
import com.sathish.tunenest.data.LibraryStore
import com.sathish.tunenest.data.Song
import com.sathish.tunenest.net.LocalMusic
import com.sathish.tunenest.net.RadioApi
import com.sathish.tunenest.net.YouTubeApi
import com.sathish.tunenest.playback.PlayerController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class SearchFilter(val label: String) {
    ALL("All"),
    YOUTUBE("YouTube"),
    LOCAL("My files"),
    RADIO("Radio"),
}

/** Kept above the screen so results survive switching tabs. */
class SearchState {
    var query by mutableStateOf("")
    var filter by mutableStateOf(SearchFilter.ALL)
    var youtube by mutableStateOf<List<Song>>(emptyList())
    var local by mutableStateOf<List<Song>>(emptyList())
    var radio by mutableStateOf<List<Song>>(emptyList())
    var ytError by mutableStateOf<String?>(null)
    var radioError by mutableStateOf<String?>(null)
    var loadingYt by mutableStateOf(false)
    var loadingRadio by mutableStateOf(false)
    var loadingLocal by mutableStateOf(false)
    private var allLocal: List<Song>? = null
    private val searchedFor = mutableMapOf<SearchFilter, String>()

    fun resetLocal() {
        allLocal = null
        searchedFor.remove(SearchFilter.LOCAL)
    }

    /** Runs only the sources the current filter needs, and only when the query changed. */
    fun run(scope: CoroutineScope, context: Context, apiKey: String) {
        val q = query.trim()
        val wantYt = (filter == SearchFilter.ALL || filter == SearchFilter.YOUTUBE) && q.isNotEmpty()
        val wantLocal = filter == SearchFilter.LOCAL || (filter == SearchFilter.ALL && q.isNotEmpty())
        val wantRadio = filter == SearchFilter.RADIO || (filter == SearchFilter.ALL && q.isNotEmpty())

        if (wantYt && searchedFor[SearchFilter.YOUTUBE] != q) {
            if (apiKey.isBlank()) {
                youtube = emptyList()
                ytError = "Add your YouTube API key in Settings to search YouTube."
            } else {
                searchedFor[SearchFilter.YOUTUBE] = q
                loadingYt = true
                ytError = null
                scope.launch {
                    val r = withContext(Dispatchers.IO) { runCatching { YouTubeApi.search(q, apiKey) } }
                    r.onSuccess {
                        youtube = it
                        if (it.isEmpty()) ytError = "No YouTube results for \"$q\"."
                    }.onFailure {
                        youtube = emptyList()
                        ytError = it.message ?: "YouTube search failed."
                        searchedFor.remove(SearchFilter.YOUTUBE)
                    }
                    loadingYt = false
                }
            }
        }

        if (wantLocal && searchedFor[SearchFilter.LOCAL] != q && LocalMusic.hasPermission(context)) {
            searchedFor[SearchFilter.LOCAL] = q
            loadingLocal = true
            scope.launch {
                val all = allLocal ?: withContext(Dispatchers.IO) {
                    runCatching { LocalMusic.loadAll(context) }.getOrDefault(emptyList())
                }.also { allLocal = it }
                local = if (q.isEmpty()) all else all.filter {
                    it.title.contains(q, ignoreCase = true) || it.artist.contains(q, ignoreCase = true)
                }
                loadingLocal = false
            }
        }

        if (wantRadio && searchedFor[SearchFilter.RADIO] != q) {
            searchedFor[SearchFilter.RADIO] = q
            loadingRadio = true
            radioError = null
            scope.launch {
                val r = withContext(Dispatchers.IO) { runCatching { RadioApi.search(q) } }
                r.onSuccess {
                    radio = it
                    if (it.isEmpty()) radioError = "No stations found."
                }.onFailure {
                    radio = emptyList()
                    radioError = it.message ?: "Radio search failed."
                    searchedFor.remove(SearchFilter.RADIO)
                }
                loadingRadio = false
            }
        }
    }
}

@Composable
fun SearchScreen(
    state: SearchState,
    library: Library,
    store: LibraryStore,
    controller: PlayerController,
    apiKey: String,
    currentSongId: String?,
    onAddToPlaylist: (Song) -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val focus = LocalFocusManager.current
    var hasLocalPermission by androidx.compose.runtime.remember { mutableStateOf(LocalMusic.hasPermission(context)) }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        hasLocalPermission = granted
        if (granted) {
            state.resetLocal()
            state.run(scope, context, apiKey)
        }
    }

    LaunchedEffect(state.filter) { state.run(scope, context, apiKey) }

    fun actionsFor(s: Song) = listOf(
        SongAction("Play next") { controller.playNext(s) },
        SongAction("Add to playlist") { onAddToPlaylist(s) },
        SongAction(if (s.id in library.liked) "Remove from Liked" else "Like") { store.toggleLike(s) },
    )

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Text(
            "Search",
            color = Palette.Text,
            fontSize = 26.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 16.dp, bottom = 12.dp),
        )
        OutlinedTextField(
            value = state.query,
            onValueChange = { state.query = it },
            placeholder = { Text("Songs, artists, stations") },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            trailingIcon = {
                if (state.query.isNotEmpty()) {
                    IconButton(onClick = { state.query = "" }) {
                        Icon(Icons.Filled.Close, contentDescription = "Clear")
                    }
                }
            },
            singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = {
                focus.clearFocus()
                state.run(scope, context, apiKey)
            }),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Palette.Accent,
                unfocusedBorderColor = Palette.Line,
                focusedContainerColor = Palette.Surface,
                unfocusedContainerColor = Palette.Surface,
            ),
            modifier = Modifier.fillMaxWidth(),
        )
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.padding(vertical = 12.dp),
        ) {
            items(SearchFilter.entries.toList()) { f ->
                Pill(f.label, state.filter == f) { state.filter = f }
            }
        }

        val q = state.query.trim()
        val f = state.filter
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 16.dp),
        ) {
            if (f == SearchFilter.ALL && q.isEmpty()) {
                item { HintText("Search YouTube, the music files on your phone, and live radio — all at once.") }
            }

            // YouTube
            if ((f == SearchFilter.ALL || f == SearchFilter.YOUTUBE) && (q.isNotEmpty() || state.ytError != null)) {
                item { SourceHeader("YouTube", state.loadingYt) }
                state.ytError?.let { err -> item { HintText(err, Modifier.padding(vertical = 6.dp)) } }
                val list = if (f == SearchFilter.ALL) state.youtube.take(6) else state.youtube
                itemsIndexed(list) { i, s ->
                    SongRow(s, s.id == currentSongId, { controller.playQueue(state.youtube, i) }, actionsFor(s))
                }
                if (f == SearchFilter.ALL && state.youtube.size > 6) {
                    item { TextButton(onClick = { state.filter = SearchFilter.YOUTUBE }) { Text("See all YouTube results") } }
                }
            }

            // Local files
            if (f == SearchFilter.LOCAL || (f == SearchFilter.ALL && q.isNotEmpty())) {
                item { SourceHeader("My files", state.loadingLocal) }
                if (!hasLocalPermission) {
                    item {
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Palette.Surface)
                                .padding(14.dp)
                        ) {
                            HintText("Allow access to play the music files saved on this phone.")
                            Button(
                                onClick = { permissionLauncher.launch(LocalMusic.permission()) },
                                colors = ButtonDefaults.buttonColors(containerColor = Palette.Accent, contentColor = Palette.Bg),
                                modifier = Modifier.padding(top = 10.dp),
                            ) { Text("Allow access") }
                        }
                    }
                } else {
                    val list = if (f == SearchFilter.ALL) state.local.take(6) else state.local
                    if (!state.loadingLocal && state.local.isEmpty()) {
                        item { HintText(if (q.isEmpty()) "No music files found on this phone." else "No matching files.", Modifier.padding(vertical = 6.dp)) }
                    }
                    itemsIndexed(list) { i, s ->
                        SongRow(s, s.id == currentSongId, { controller.playQueue(state.local, i) }, actionsFor(s))
                    }
                    if (f == SearchFilter.ALL && state.local.size > 6) {
                        item { TextButton(onClick = { state.filter = SearchFilter.LOCAL }) { Text("See all files") } }
                    }
                }
            }

            // Radio
            if (f == SearchFilter.RADIO || (f == SearchFilter.ALL && q.isNotEmpty())) {
                item { SourceHeader(if (q.isEmpty()) "Popular stations in India" else "Radio", state.loadingRadio) }
                state.radioError?.let { err -> item { HintText(err, Modifier.padding(vertical = 6.dp)) } }
                val list = if (f == SearchFilter.ALL) state.radio.take(5) else state.radio
                itemsIndexed(list) { i, s ->
                    SongRow(s, s.id == currentSongId, { controller.playQueue(state.radio, i) }, actionsFor(s))
                }
                if (f == SearchFilter.ALL && state.radio.size > 5) {
                    item { TextButton(onClick = { state.filter = SearchFilter.RADIO }) { Text("See all stations") } }
                }
            }
        }
    }
}

@Composable
private fun SourceHeader(title: String, loading: Boolean) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(top = 14.dp, bottom = 4.dp),
    ) {
        SectionTitle(title, Modifier.weight(1f))
        if (loading) CircularProgressIndicator(color = Palette.Accent, strokeWidth = 2.dp, modifier = Modifier.size(18.dp))
    }
}
