package com.sathish.tunenest

import android.app.Application
import android.content.Context
import com.sathish.tunenest.data.LibraryStore
import com.sathish.tunenest.data.Prefs
import com.sathish.tunenest.playback.PlayerController
import java.io.File

class TuneApp : Application() {
    lateinit var prefs: Prefs
        private set
    lateinit var library: LibraryStore
        private set
    lateinit var player: PlayerController
        private set

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        library = LibraryStore(File(filesDir, "library.json"))
        player = PlayerController(this, library, prefs)
    }
}

val Context.tuneApp: TuneApp
    get() = applicationContext as TuneApp
