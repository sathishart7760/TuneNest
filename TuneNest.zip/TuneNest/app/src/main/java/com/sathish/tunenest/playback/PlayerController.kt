package com.sathish.tunenest.playback

import android.app.Application
import android.content.ComponentName
import android.graphics.Bitmap
import android.net.Uri
import androidx.core.content.ContextCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.PlayerConstants
import com.sathish.tunenest.data.LibraryStore
import com.sathish.tunenest.data.Prefs
import com.sathish.tunenest.data.Song
import com.sathish.tunenest.data.Source
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class Engine { NONE, NATIVE, YT_EMBED, YT_MUSIC }

enum class RepeatMode { OFF, ALL, ONE }

data class PlayerUi(
    val queue: List<Song> = emptyList(),
    val index: Int = -1,
    val isPlaying: Boolean = false,
    val isBuffering: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val engine: Engine = Engine.NONE,
    val shuffle: Boolean = false,
    val repeat: RepeatMode = RepeatMode.OFF,
    val videoMode: Boolean = true,
    val message: String? = null,
    val posterArt: Bitmap? = null,
) {
    val current: Song? get() = queue.getOrNull(index)
}

/**
 * One queue for every source. Local files and radio play through ExoPlayer (background + lock screen),
 * YouTube songs through the official embedded player (Video) or the YouTube Music app (Poster).
 */
class PlayerController(
    private val app: Application,
    private val library: LibraryStore,
    private val prefs: Prefs,
) {
    private val scope = MainScope()
    private val _ui = MutableStateFlow(PlayerUi(videoMode = prefs.videoMode))
    val ui: StateFlow<PlayerUi> = _ui.asStateFlow()

    val youtube = YouTubeHost(this)
    val ytMusic = YtMusicBridge(app)

    /** Set by MainActivity: is the app on screen right now? */
    var appVisible: Boolean = false

    private var originalQueue: List<Song> = emptyList()
    private var native: MediaController? = null
    private var nativeFuture: ListenableFuture<MediaController>? = null
    private val pendingNative = mutableListOf<(MediaController) -> Unit>()
    private var posterTitle: String? = null

    init {
        scope.launch {
            while (isActive) {
                tick()
                delay(500)
            }
        }
    }

    // ---------------- Public controls ----------------

    fun playQueue(songs: List<Song>, startIndex: Int) {
        if (songs.isEmpty()) return
        val start = startIndex.coerceIn(0, songs.lastIndex)
        originalQueue = songs
        if (_ui.value.shuffle) {
            val first = songs[start]
            val rest = songs.filterIndexed { i, _ -> i != start }.shuffled()
            _ui.update { it.copy(queue = listOf(first) + rest, index = 0) }
        } else {
            _ui.update { it.copy(queue = songs, index = start) }
        }
        startCurrent()
    }

    fun playShuffled(songs: List<Song>) {
        if (songs.isEmpty()) return
        _ui.update { it.copy(shuffle = true) }
        playQueue(songs, songs.indices.random())
    }

    fun playNext(song: Song) {
        val u = _ui.value
        if (u.current == null) {
            playQueue(listOf(song), 0)
            return
        }
        val q = u.queue.toMutableList()
        q.add(u.index + 1, song)
        originalQueue = originalQueue + song
        _ui.update { it.copy(queue = q, message = "Playing next: ${song.title}") }
    }

    fun togglePlayPause() {
        val u = _ui.value
        if (u.current == null) return
        when (u.engine) {
            Engine.NATIVE -> native?.let { c ->
                if (c.isPlaying) {
                    c.pause()
                } else {
                    if (c.playbackState == Player.STATE_IDLE) c.prepare()
                    if (c.playbackState == Player.STATE_ENDED) c.seekTo(0)
                    c.play()
                }
            }
            Engine.YT_EMBED -> if (u.isPlaying) youtube.pause() else youtube.play()
            Engine.YT_MUSIC -> if (u.isPlaying) ytMusic.pause() else ytMusic.play()
            Engine.NONE -> startCurrent()
        }
    }

    fun next() = advance(byUser = true)

    fun previous() {
        val u = _ui.value
        if (u.queue.isEmpty()) return
        if (u.positionMs > 3_000 && u.current?.source != Source.RADIO) {
            seekTo(0)
            return
        }
        val prev = if (u.index > 0) u.index - 1 else u.queue.lastIndex
        _ui.update { it.copy(index = prev) }
        startCurrent()
    }

    fun jumpTo(index: Int) {
        if (index !in _ui.value.queue.indices) return
        _ui.update { it.copy(index = index) }
        startCurrent()
    }

    fun seekTo(ms: Long) {
        when (_ui.value.engine) {
            Engine.NATIVE -> native?.seekTo(ms)
            Engine.YT_EMBED -> youtube.seekTo(ms / 1000f)
            Engine.YT_MUSIC -> ytMusic.seekTo(ms)
            Engine.NONE -> Unit
        }
        _ui.update { it.copy(positionMs = ms) }
    }

    fun toggleShuffle() {
        val u = _ui.value
        val cur = u.current
        if (!u.shuffle) {
            if (cur != null) {
                val rest = u.queue.filterIndexed { i, _ -> i != u.index }.shuffled()
                _ui.update { it.copy(shuffle = true, queue = listOf(cur) + rest, index = 0) }
            } else {
                _ui.update { it.copy(shuffle = true) }
            }
        } else {
            val restored = if (originalQueue.isNotEmpty()) originalQueue else u.queue
            val idx = if (cur != null) restored.indexOfFirst { it.id == cur.id } else -1
            _ui.update {
                it.copy(shuffle = false, queue = restored, index = if (idx >= 0) idx else it.index.coerceAtMost(restored.lastIndex))
            }
        }
    }

    fun cycleRepeat() {
        _ui.update {
            it.copy(
                repeat = when (it.repeat) {
                    RepeatMode.OFF -> RepeatMode.ALL
                    RepeatMode.ALL -> RepeatMode.ONE
                    RepeatMode.ONE -> RepeatMode.OFF
                }
            )
        }
    }

    /** Video = YouTube player inside the app. Poster = artwork here, audio in YouTube Music. */
    fun setVideoMode(video: Boolean) {
        if (!video && !ytMusic.isInstalled()) {
            setMessage("Install YouTube Music to use Poster mode for YouTube songs.")
            return
        }
        prefs.videoMode = video
        _ui.update { it.copy(videoMode = video) }
        val u = _ui.value
        val song = u.current ?: return
        if (song.source != Source.YOUTUBE) return
        if (video && u.engine == Engine.YT_MUSIC) {
            val pos = u.positionMs
            ytMusic.pause()
            setEngine(Engine.YT_EMBED)
            youtube.load(song.ref, pos / 1000f)
        } else if (!video && u.engine == Engine.YT_EMBED) {
            youtube.pause()
            setEngine(Engine.YT_MUSIC)
            posterTitle = null
            _ui.update { it.copy(posterArt = null) }
            ytMusic.handoff(song, appVisible)
        }
    }

    fun openYtMusic() = ytMusic.openApp()

    fun clearMessage() = _ui.update { it.copy(message = null) }

    // ---------------- Engine plumbing ----------------

    private fun startCurrent(startMs: Long = 0L) {
        val song = _ui.value.current ?: return
        pauseAll()
        library.recordPlay(song)
        posterTitle = null
        _ui.update {
            it.copy(
                positionMs = startMs,
                durationMs = song.durationMs,
                isPlaying = false,
                isBuffering = true,
                posterArt = null,
                message = null,
            )
        }
        when (song.source) {
            Source.LOCAL, Source.RADIO -> {
                setEngine(Engine.NATIVE)
                withNative { c ->
                    c.setMediaItem(song.toMediaItem(), startMs)
                    c.prepare()
                    c.play()
                }
            }
            Source.YOUTUBE -> {
                val poster = !_ui.value.videoMode && ytMusic.isInstalled()
                if (poster) {
                    setEngine(Engine.YT_MUSIC)
                    ytMusic.handoff(song, appVisible)
                } else {
                    setEngine(Engine.YT_EMBED)
                    youtube.load(song.ref, startMs / 1000f)
                }
            }
        }
    }

    private fun advance(byUser: Boolean) {
        val u = _ui.value
        if (u.queue.isEmpty()) return
        val atEnd = u.index >= u.queue.lastIndex
        if (atEnd && u.repeat == RepeatMode.OFF && !byUser) {
            _ui.update { it.copy(isPlaying = false, isBuffering = false) }
            return
        }
        val nextIndex = if (atEnd) 0 else u.index + 1
        _ui.update { it.copy(index = nextIndex) }
        startCurrent()
    }

    private fun onTrackEnded() {
        if (_ui.value.repeat == RepeatMode.ONE) startCurrent() else advance(byUser = false)
    }

    private fun pauseAll() {
        native?.let { if (it.playWhenReady) it.pause() }
        youtube.pause()
        if (_ui.value.engine == Engine.YT_MUSIC) ytMusic.pause()
    }

    private fun setEngine(engine: Engine) = _ui.update { it.copy(engine = engine) }

    private fun setMessage(text: String) {
        if (_ui.value.message != text) _ui.update { it.copy(message = text) }
    }

    private fun Song.toMediaItem(): MediaItem = MediaItem.Builder()
        .setMediaId(id)
        .setUri(Uri.parse(ref))
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(artist)
                .setArtworkUri(artwork?.let { Uri.parse(it) })
                .build()
        )
        .build()

    private fun withNative(block: (MediaController) -> Unit) {
        native?.let {
            block(it)
            return
        }
        pendingNative += block
        if (nativeFuture != null) return
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        nativeFuture = future
        future.addListener({
            try {
                val c = future.get()
                native = c
                c.addListener(nativeListener)
                val todo = pendingNative.toList()
                pendingNative.clear()
                todo.forEach { it(c) }
            } catch (e: Exception) {
                nativeFuture = null
                pendingNative.clear()
                setMessage("Player could not start: ${e.message}")
            }
        }, ContextCompat.getMainExecutor(app))
    }

    private val nativeListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            if (_ui.value.engine == Engine.NATIVE) _ui.update { it.copy(isPlaying = isPlaying) }
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            if (_ui.value.engine != Engine.NATIVE) return
            _ui.update { it.copy(isBuffering = playbackState == Player.STATE_BUFFERING) }
            if (playbackState == Player.STATE_ENDED) onTrackEnded()
        }

        override fun onPlayerError(error: PlaybackException) {
            if (_ui.value.engine != Engine.NATIVE) return
            _ui.update { it.copy(isBuffering = false, isPlaying = false) }
            setMessage("Can't play this one (${error.errorCodeName}). Try another.")
        }
    }

    private fun tick() {
        when (_ui.value.engine) {
            Engine.NATIVE -> native?.let { c ->
                val d = c.duration
                _ui.update {
                    it.copy(
                        positionMs = c.currentPosition.coerceAtLeast(0L),
                        durationMs = if (d == C.TIME_UNSET || d < 0) 0L else d,
                    )
                }
            }
            Engine.YT_MUSIC -> pollYtMusic()
            else -> Unit
        }
    }

    private fun pollYtMusic() {
        val snap = ytMusic.snapshot()
        if (snap == null) {
            if (!ytMusic.hasAccess()) {
                setMessage("Allow notification access in Settings so TuneNest can control YouTube Music.")
            }
            return
        }
        val newArt = if (snap.title != posterTitle && snap.art != null) {
            posterTitle = snap.title
            snap.art
        } else null
        _ui.update {
            it.copy(
                isPlaying = snap.isPlaying,
                isBuffering = false,
                positionMs = snap.positionMs,
                durationMs = if (snap.durationMs > 0) snap.durationMs else it.durationMs,
                posterArt = newArt ?: it.posterArt,
            )
        }
        if (ytMusic.songFinished(snap)) onTrackEnded()
    }

    // ---------------- YouTube embedded player callbacks ----------------

    fun onYouTubeState(state: PlayerConstants.PlayerState) {
        if (_ui.value.engine != Engine.YT_EMBED) return
        when (state) {
            PlayerConstants.PlayerState.PLAYING ->
                _ui.update { it.copy(isPlaying = true, isBuffering = false) }
            PlayerConstants.PlayerState.PAUSED,
            PlayerConstants.PlayerState.VIDEO_CUED ->
                _ui.update { it.copy(isPlaying = false, isBuffering = false) }
            PlayerConstants.PlayerState.BUFFERING ->
                _ui.update { it.copy(isBuffering = true) }
            PlayerConstants.PlayerState.ENDED -> {
                _ui.update { it.copy(isPlaying = false) }
                onTrackEnded()
            }
            else -> Unit
        }
    }

    fun onYouTubeProgress(ms: Long) {
        if (_ui.value.engine == Engine.YT_EMBED) _ui.update { it.copy(positionMs = ms) }
    }

    fun onYouTubeDuration(ms: Long) {
        if (_ui.value.engine == Engine.YT_EMBED && ms > 0) _ui.update { it.copy(durationMs = ms) }
    }

    fun onYouTubeError(error: PlayerConstants.PlayerError) {
        if (_ui.value.engine != Engine.YT_EMBED) return
        val song = _ui.value.current ?: return
        _ui.update { it.copy(isBuffering = false, isPlaying = false) }
        if (error == PlayerConstants.PlayerError.VIDEO_NOT_PLAYABLE_IN_EMBEDDED_PLAYER && ytMusic.isInstalled()) {
            setEngine(Engine.YT_MUSIC)
            ytMusic.handoff(song, appVisible)
            setMessage("This video can't play inside other apps, so it's playing in YouTube Music.")
        } else {
            setMessage(
                when (error) {
                    PlayerConstants.PlayerError.VIDEO_NOT_PLAYABLE_IN_EMBEDDED_PLAYER ->
                        "This video can't play inside other apps."
                    PlayerConstants.PlayerError.VIDEO_NOT_FOUND -> "This video was removed or is private."
                    else -> "YouTube couldn't play this video."
                }
            )
        }
    }
}
