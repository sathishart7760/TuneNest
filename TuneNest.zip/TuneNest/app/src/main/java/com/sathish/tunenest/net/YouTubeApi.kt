package com.sathish.tunenest.net

import android.text.Html
import com.sathish.tunenest.data.Song
import com.sathish.tunenest.data.Source
import org.json.JSONObject

/** YouTube Data API v3 (free key, ~100 searches/day on the default quota). */
object YouTubeApi {
    private const val BASE = "https://www.googleapis.com/youtube/v3"

    fun search(query: String, key: String): List<Song> {
        val url = "$BASE/search?part=snippet&type=video&videoEmbeddable=true&videoCategoryId=10" +
            "&maxResults=25&q=${Http.enc(query)}&key=${Http.enc(key)}"
        val json = JSONObject(Http.get(url))
        val items = json.optJSONArray("items") ?: return emptyList()
        val out = mutableListOf<Song>()
        for (i in 0 until items.length()) {
            val item = items.getJSONObject(i)
            val videoId = item.optJSONObject("id")?.optString("videoId").orEmpty()
            val sn = item.optJSONObject("snippet") ?: continue
            if (videoId.isBlank()) continue
            out += Song(
                source = Source.YOUTUBE,
                ref = videoId,
                title = clean(sn.optString("title")),
                artist = cleanArtist(sn.optString("channelTitle")),
                artwork = thumbnail(videoId),
            )
        }
        return out
    }

    /** Accepts a full playlist link or a bare playlist id. */
    fun parsePlaylistId(input: String): String? {
        val t = input.trim()
        Regex("[?&]list=([A-Za-z0-9_-]+)").find(t)?.let { return it.groupValues[1] }
        return t.takeIf { Regex("^[A-Za-z0-9_-]{10,}$").matches(it) }
    }

    fun playlistTitle(playlistId: String, key: String): String? {
        val json = JSONObject(Http.get("$BASE/playlists?part=snippet&id=${Http.enc(playlistId)}&key=${Http.enc(key)}"))
        val items = json.optJSONArray("items") ?: return null
        if (items.length() == 0) return null
        return items.getJSONObject(0).optJSONObject("snippet")?.optString("title")?.let { clean(it) }
    }

    fun playlistSongs(playlistId: String, key: String, max: Int = 500): List<Song> {
        val out = mutableListOf<Song>()
        var pageToken: String? = null
        do {
            val url = "$BASE/playlistItems?part=snippet&maxResults=50&playlistId=${Http.enc(playlistId)}" +
                "&key=${Http.enc(key)}" + (pageToken?.let { "&pageToken=${Http.enc(it)}" } ?: "")
            val json = JSONObject(Http.get(url))
            val items = json.optJSONArray("items")
            if (items != null) {
                for (i in 0 until items.length()) {
                    val sn = items.getJSONObject(i).optJSONObject("snippet") ?: continue
                    val videoId = sn.optJSONObject("resourceId")?.optString("videoId").orEmpty()
                    val title = clean(sn.optString("title"))
                    if (videoId.isBlank() || title == "Deleted video" || title == "Private video") continue
                    out += Song(
                        source = Source.YOUTUBE,
                        ref = videoId,
                        title = title,
                        artist = cleanArtist(sn.optString("videoOwnerChannelTitle").ifBlank { "YouTube" }),
                        artwork = thumbnail(videoId),
                    )
                }
            }
            pageToken = json.optString("nextPageToken").takeIf { it.isNotBlank() }
        } while (pageToken != null && out.size < max)
        return out
    }

    /** 16:9 thumbnail without black bars. */
    fun thumbnail(videoId: String) = "https://i.ytimg.com/vi/$videoId/mqdefault.jpg"

    /** Larger thumbnail for the Now Playing poster (falls back to [thumbnail] if missing). */
    fun posterThumbnail(videoId: String) = "https://i.ytimg.com/vi/$videoId/hq720.jpg"

    private fun clean(s: String): String = Html.fromHtml(s, Html.FROM_HTML_MODE_LEGACY).toString().trim()

    private fun cleanArtist(s: String): String = clean(s).removeSuffix(" - Topic").trim()
}
