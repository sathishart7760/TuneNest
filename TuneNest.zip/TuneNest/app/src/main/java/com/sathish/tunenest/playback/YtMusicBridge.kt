package com.sathish.tunenest.playback

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import androidx.core.app.NotificationManagerCompat
import com.sathish.tunenest.data.Song

/**
 * Poster mode for YouTube songs: audio plays in the YouTube Music app (your Premium gives
 * background play), and this app shows the poster and controls it through Android's media controls.
 */
class YtMusicBridge(private val context: Context) {

    companion object {
        const val PACKAGE = "com.google.android.apps.youtube.music"
    }

    data class Snapshot(
        val title: String?,
        val isPlaying: Boolean,
        val positionMs: Long,
        val durationMs: Long,
        val art: Bitmap?,
    )

    private var handoffAt = 0L
    private var baselineTitle: String? = null
    private var endedFired = false

    fun isInstalled(): Boolean = context.packageManager.getLaunchIntentForPackage(PACKAGE) != null

    fun hasAccess(): Boolean =
        NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.packageName)

    private fun findController(): MediaController? {
        if (!hasAccess()) return null
        return try {
            val msm = context.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            msm.getActiveSessions(ComponentName(context, MediaListenerService::class.java))
                .firstOrNull { it.packageName == PACKAGE }
        } catch (e: SecurityException) {
            null
        }
    }

    /**
     * Starts [song] in YouTube Music. Uses YT Music's media controls when it supports it
     * (no app switch), otherwise opens the song in the YT Music app.
     */
    fun handoff(song: Song, appVisible: Boolean) {
        handoffAt = SystemClock.elapsedRealtime()
        baselineTitle = null
        endedFired = false
        val url = Uri.parse("https://music.youtube.com/watch?v=${song.ref}")
        val c = findController()
        val actions = c?.playbackState?.actions ?: 0L
        when {
            c != null && actions and PlaybackState.ACTION_PLAY_FROM_URI != 0L ->
                c.transportControls.playFromUri(url, Bundle())
            appVisible -> openSong(url)
            c != null && actions and PlaybackState.ACTION_PLAY_FROM_SEARCH != 0L ->
                c.transportControls.playFromSearch("${song.title} ${song.artist}", Bundle())
            else -> openSong(url)
        }
    }

    private fun openSong(url: Uri) {
        try {
            context.startActivity(
                Intent(Intent.ACTION_VIEW, url)
                    .setPackage(PACKAGE)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            // Blocked or not installed; the UI shows a hint.
        }
    }

    fun openApp() {
        context.packageManager.getLaunchIntentForPackage(PACKAGE)?.let {
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                context.startActivity(it)
            } catch (e: Exception) {
            }
        }
    }

    fun play() {
        findController()?.transportControls?.play()
    }

    fun pause() {
        findController()?.transportControls?.pause()
    }

    fun seekTo(ms: Long) {
        findController()?.transportControls?.seekTo(ms)
    }

    fun snapshot(): Snapshot? {
        val c = findController() ?: return null
        val st = c.playbackState
        val md = c.metadata
        val playing = st?.state == PlaybackState.STATE_PLAYING
        var pos = st?.position ?: 0L
        if (playing && st != null && st.lastPositionUpdateTime > 0) {
            pos += ((SystemClock.elapsedRealtime() - st.lastPositionUpdateTime) * st.playbackSpeed).toLong()
        }
        val duration = md?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
        val art = md?.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
        return Snapshot(
            title = md?.getString(MediaMetadata.METADATA_KEY_TITLE),
            isPlaying = playing,
            positionMs = pos.coerceAtLeast(0L),
            durationMs = duration.coerceAtLeast(0L),
            art = art,
        )
    }

    /** True once YT Music has moved past the song we sent it. */
    fun songFinished(s: Snapshot): Boolean {
        val sinceHandoff = SystemClock.elapsedRealtime() - handoffAt
        if (sinceHandoff < 6_000) {
            baselineTitle = s.title
            return false
        }
        if (baselineTitle == null) {
            baselineTitle = s.title
            return false
        }
        if (s.title != null && s.title != baselineTitle) {
            baselineTitle = s.title
            return true
        }
        if (!endedFired && !s.isPlaying && s.durationMs > 0 && s.positionMs >= s.durationMs - 1_500) {
            endedFired = true
            return true
        }
        return false
    }
}
