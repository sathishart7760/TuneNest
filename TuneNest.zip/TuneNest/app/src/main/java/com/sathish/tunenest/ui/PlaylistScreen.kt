package com.sathish.tunenest.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sathish.tunenest.data.Library
import com.sathish.tunenest.data.LibraryStore
import com.sathish.tunenest.data.Song
import com.sathish.tunenest.playback.PlayerController

enum class SmartKind(val title: String) {
    LIKED("Liked Songs"),
    RECENT("Recently Played"),
    MOST("Most Played"),
}

@Composable
fun PlaylistScreen(
    playlistId: String?,
    smart: SmartKind?,
    library: Library,
    store: LibraryStore,
    controller: PlayerController,
    currentSongId: String?,
    onBack: () -> Unit,
    onAddToPlaylist: (Song) -> Unit,
) {
    val playlist = playlistId?.let { id -> library.playlists.firstOrNull { it.id == id } }
    if (playlistId != null && playlist == null) {
        LaunchedEffect(Unit) { onBack() }
        return
    }
    val title = playlist?.name ?: smart?.title ?: ""
    val songs: List<Song> = when {
        playlist != null -> library.songsOf(playlist.songIds)
        smart == SmartKind.LIKED -> library.likedSongs()
        smart == SmartKind.RECENT -> library.recentSongs()
        smart == SmartKind.MOST -> library.mostPlayed()
        else -> emptyList()
    }
    val categoryName = library.categoryName(playlist?.categoryId)

    var menu by remember { mutableStateOf(false) }
    var rename by remember { mutableStateOf(false) }
    var move by remember { mutableStateOf(false) }
    var delete by remember { mutableStateOf(false) }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = Palette.Text)
                }
                Text(
                    listOfNotNull(categoryName, title).joinToString("  ›  "),
                    color = Palette.TextDim,
                    fontSize = 13.sp,
                    modifier = Modifier.weight(1f),
                    maxLines = 1,
                )
                if (playlist != null) {
                    Box {
                        IconButton(onClick = { menu = true }) {
                            Icon(Icons.Filled.MoreVert, contentDescription = "Playlist options", tint = Palette.Text)
                        }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            DropdownMenuItem(text = { Text("Rename") }, onClick = { menu = false; rename = true })
                            DropdownMenuItem(text = { Text("Move to category") }, onClick = { menu = false; move = true })
                            DropdownMenuItem(text = { Text("Delete playlist") }, onClick = { menu = false; delete = true })
                        }
                    }
                }
            }
        }

        item {
            Row(verticalAlignment = Alignment.Bottom, modifier = Modifier.padding(vertical = 8.dp)) {
                PlaylistCover(songs, 132.dp, corner = 12.dp)
                Column(Modifier.padding(start = 16.dp)) {
                    Text(title, color = Palette.Text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    val total = songs.sumOf { it.durationMs }
                    Text(
                        if (total > 0) "${songs.size} songs  ·  ${formatTime(total)}" else "${songs.size} songs",
                        color = Palette.TextDim,
                        fontSize = 13.sp,
                    )
                    if (categoryName != null) Text("Category: $categoryName", color = Palette.TextDim, fontSize = 13.sp)
                }
            }
        }

        item {
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.padding(bottom = 8.dp),
            ) {
                Button(
                    onClick = { controller.playQueue(songs, 0) },
                    enabled = songs.isNotEmpty(),
                    shape = RoundedCornerShape(24.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Palette.Accent, contentColor = Palette.Bg),
                    modifier = Modifier.height(48.dp),
                ) {
                    Icon(Icons.Filled.PlayArrow, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("Play", fontWeight = FontWeight.Bold)
                }
                OutlinedButton(
                    onClick = { controller.playShuffled(songs) },
                    enabled = songs.isNotEmpty(),
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.height(48.dp),
                ) {
                    Icon(Icons.Filled.Shuffle, contentDescription = null, tint = Palette.Text, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Shuffle", color = Palette.Text)
                }
            }
        }

        if (songs.isEmpty()) {
            item {
                HintText(
                    when (smart) {
                        SmartKind.LIKED -> "Tap the heart on any song to see it here."
                        SmartKind.RECENT, SmartKind.MOST -> "Play some music and it will show up here."
                        null -> "Find songs in Search and use the ⋮ menu to add them here."
                    }
                )
            }
        }

        itemsIndexed(songs) { i, s ->
            val actions = buildList {
                add(SongAction("Play next") { controller.playNext(s) })
                add(SongAction("Add to playlist") { onAddToPlaylist(s) })
                add(SongAction(if (s.id in library.liked) "Remove from Liked" else "Like") { store.toggleLike(s) })
                if (playlist != null) add(SongAction("Remove from this playlist") { store.removeFromPlaylist(playlist.id, s.id) })
            }
            SongRow(
                song = s,
                highlighted = s.id == currentSongId,
                onClick = { controller.playQueue(songs, i) },
                actions = actions,
            )
        }
    }

    if (rename && playlist != null) {
        TextPromptDialog(
            title = "Rename playlist",
            initial = playlist.name,
            confirmLabel = "Save",
            onDismiss = { rename = false },
            onConfirm = {
                store.renamePlaylist(playlist.id, it)
                rename = false
            },
        )
    }
    if (move && playlist != null) {
        CategoryPickerDialog(
            categories = library.categories,
            selected = playlist.categoryId,
            onDismiss = { move = false },
            onPick = {
                store.movePlaylist(playlist.id, it)
                move = false
            },
        )
    }
    if (delete && playlist != null) {
        AlertDialog(
            onDismissRequest = { delete = false },
            title = { Text("Delete ${playlist.name}?") },
            text = { Text("The songs stay in your other playlists and Liked Songs.") },
            confirmButton = {
                TextButton(onClick = {
                    delete = false
                    store.deletePlaylist(playlist.id)
                    onBack()
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { delete = false }) { Text("Cancel") } },
            containerColor = Palette.Surface,
        )
    }
}
