package com.sathish.tunenest.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object Palette {
    val Bg = Color(0xFF0E0F12)
    val Surface = Color(0xFF181A1F)
    val Surface2 = Color(0xFF23262E)
    val Line = Color(0xFF2A2D35)
    val Text = Color(0xFFF2F2F4)
    val TextDim = Color(0xFFA6AAB4)
    val Accent = Color(0xFFF2A93B)

    val YouTubeBg = Color(0xFF4A1C1E)
    val YouTubeFg = Color(0xFFFF9EA1)
    val LocalBg = Color(0xFF172A4A)
    val LocalFg = Color(0xFF9EC2FF)
    val RadioBg = Color(0xFF123A36)
    val RadioFg = Color(0xFF8EE5DA)

    /** Background + icon color pairs for category cards. */
    val categoryColors = listOf(
        Color(0xFF1E2A24) to Color(0xFF7FD3A8),
        Color(0xFF2E2218) to Color(0xFFF2A93B),
        Color(0xFF1C2433) to Color(0xFF7FA8F2),
        Color(0xFF2C1C2C) to Color(0xFFE79AE0),
        Color(0xFF2A2A18) to Color(0xFFE0D46A),
        Color(0xFF1A2A2E) to Color(0xFF6AD4E0),
    )
}

@Composable
fun TuneTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Palette.Accent,
            onPrimary = Palette.Bg,
            secondary = Palette.Accent,
            onSecondary = Palette.Bg,
            background = Palette.Bg,
            onBackground = Palette.Text,
            surface = Palette.Surface,
            onSurface = Palette.Text,
            surfaceVariant = Palette.Surface2,
            onSurfaceVariant = Palette.TextDim,
            secondaryContainer = Palette.Surface2,
            onSecondaryContainer = Palette.Text,
            outline = Palette.Line,
        ),
        content = content,
    )
}
